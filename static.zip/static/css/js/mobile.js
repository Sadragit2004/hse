// Mobile-specific JavaScript
class MobileHSE {
    constructor() {
        this.init();
    }

    init() {
        // Prevent pull-to-refresh on mobile
        this.preventPullToRefresh();

        // Handle swipe gestures
        this.initSwipeGestures();

        // Handle back button
        this.handleBackButton();

        // Optimize images for mobile
        this.optimizeImages();
    }

    preventPullToRefresh() {
        let startY;
        const main = document.querySelector('main');

        main.addEventListener('touchstart', e => {
            startY = e.touches[0].clientY;
        }, { passive: true });

        main.addEventListener('touchmove', e => {
            const y = e.touches[0].clientY;
            // If user is scrolling up from top, prevent default
            if (window.scrollY === 0 && y > startY) {
                e.preventDefault();
            }
        }, { passive: false });
    }

    initSwipeGestures() {
        let startX, startY;
        const threshold = 50; // Minimum swipe distance

        document.addEventListener('touchstart', e => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        });

        document.addEventListener('touchend', e => {
            if (!startX || !startY) return;

            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            const diffX = startX - endX;
            const diffY = startY - endY;

            // Horizontal swipe (for tab navigation)
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > threshold) {
                if (diffX > 0) {
                    // Swipe left - next tab
                    this.swipeNext();
                } else {
                    // Swipe right - previous tab
                    this.swipePrev();
                }
            }
        });
    }

    swipeNext() {
        const activeTab = document.querySelector('.tab-active');
        const tabs = document.querySelectorAll('.tab-item');
        const nextIndex = Array.from(tabs).indexOf(activeTab) + 1;

        if (nextIndex < tabs.length) {
            tabs[nextIndex].click();
        }
    }

    swipePrev() {
        const activeTab = document.querySelector('.tab-active');
        const tabs = document.querySelectorAll('.tab-item');
        const prevIndex = Array.from(tabs).indexOf(activeTab) - 1;

        if (prevIndex >= 0) {
            tabs[prevIndex].click();
        }
    }

    handleBackButton() {
        // Handle Android back button
        window.addEventListener('popstate', () => {
            const modals = document.querySelectorAll('[class*="modal"]:not([class*="hidden"])');
            if (modals.length > 0) {
                modals[modals.length - 1].classList.add('hidden');
                history.pushState(null, null, window.location.pathname);
            }
        });
    }

    optimizeImages() {
        // Lazy load images for better performance
        const images = document.querySelectorAll('img[data-src]');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    observer.unobserve(img);
                }
            });
        });

        images.forEach(img => observer.observe(img));
    }

    // Utility function for mobile alerts
    showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `fixed bottom-20 right-4 left-4 bg-${type === 'success' ? 'green' : type === 'error' ? 'red' : 'blue'}-500 text-white p-3 rounded-lg shadow-lg z-50 transform transition-all duration-300`;
        toast.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} ml-2"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    // Offline detection
    initOfflineDetection() {
        window.addEventListener('online', () => {
            this.showToast('اتصال به اینترنت برقرار شد', 'success');
        });

        window.addEventListener('offline', () => {
            this.showToast('اتصال به اینترنت قطع شد', 'error', 5000);
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.mobileHSE = new MobileHSE();
});